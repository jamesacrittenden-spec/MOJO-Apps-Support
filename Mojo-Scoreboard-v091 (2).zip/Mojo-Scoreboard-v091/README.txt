MOJO WEB SCOREBOARD v0.7 — FIREBASE HOSTING PACKAGE
Prepared 2026-11-01. This is a read-only scoring website; it is NOT deployed yet.

HOW IT WORKS
- Pick a rally from eventList; the web app reads only <event>/Cars.
- If a rally is password-protected, enter the scoreboard password. The existing
  Firebase security rules allow this browser to write ONLY its own viewer membership
  record under members/<event>/<anonymous-uid>. This is authentication, NOT score editing.
- It listens to Cars using Firebase onValue and updates automatically.
- When the first car records a checkpoint, the website adds that CP column, in numeric order.
- Headers: regular CP number; R restart; TC time check; OFF off course.
- Missing CP record: x; restart/time check passed: checkmark; timed CP: score;
  off course passed: 0 when zero penalty, otherwise its numeric penalty.
- Total: authoritative Cars/<car>/score, not a sum of individual CPs.
- Sorting: lowest total, car number, or class then score. No class filter.

IMPORTANT LIMITS
- All CP columns cannot appear until at least one competitor uploads each CP.
- A CP skipped by everyone will not appear. x may mean missing or delayed upload.
- Scoreboard users cannot see the protected CP definitions, so only car passage
  records establish CP labels. In unusual cases if a later rescoring changes
  an existing passage record the displayed label may update.
- A publicly readable scoreboard also exposes any location/position fields stored
  under the car records to people who inspect Firebase network data. That is
  inherent in the current rules and not introduced by this display.
- The current security rules authorize score editing in Rallymaster and also
  the registered car's own Competitor client. This site itself has no such access.

BEFORE DEPLOYMENT — FIREBASE PROJECT OWNER ACTION REQUIRED
1. Go to console.firebase.google.com and open project fir-tut-5e284.
2. The existing MojoCheckpoint web-app Firebase config has already been installed
   in public/index.html. No additional web app registration is needed.
3. Under Authentication > Sign-in method confirm Anonymous sign-in is enabled.
   If it is already enabled, do not change it. Verify authorized domains if needed.
4. From a Windows PowerShell terminal install Node.js LTS if not present.
   Run: npm install -g firebase-tools
5. Extract this ZIP to a folder and open PowerShell in that folder.
   Run: firebase login
   Run: firebase use fir-tut-5e284
   Run: firebase deploy --only hosting
6. The CLI prints the website URL (typically https://fir-tut-5e284.web.app).
   Test first with Demo Scamper and then with a password-protected demo event.

IMPORTANT: Do NOT run firebase init in this folder, replace the live Realtime
Database rules, import/delete data, or deploy database rules. The package deploys
only the public/ website with `firebase deploy --only hosting`.

TEST CHECKLIST
[ ] Website shows event list
[ ] Demo Scamper loads and shows correct team names, classes, official totals
[ ] Sorting changes correctly
[ ] Checkpoint columns appear in numeric order with R/TC/OFF labels
[ ] An unpassed CP displays x
[ ] An OFF passage with zero penalty displays 0
[ ] Password-protected event requires correct password
[ ] A new CP upload changes the scoreboard automatically without page reload
[ ] Score corrections made by Rallymaster show on website
[ ] Changing to a locked rally doesn't show previous rally's scores

NOTE: This package was not connected to your live Firebase account or deployed.
If firebase deploy reports an access or billing problem, do not change database
permissions; capture the exact error for troubleshooting.

V0.4 FIX: Checkpoints timed from Restart are now treated as scoring CPs, not restart CPs. Matching recognizes full CP names instead of substring "restart".

Version 0.5: Visible v0.5 in the blue page header and browser tab. Hover over a CP heading to inspect its reported Firebase CP type. No database writes added.

VERSION 0.7 CHANGES
- When any score or total includes fractional precision, all numeric scores and totals display one decimal place (including zero and OFF penalties). Otherwise they display whole numbers.
- CP columns are narrower (50px minimum instead of 62px) to show more checkpoints.
- Preserves live Firebase updates and existing access rules. No database changes.


Version 0.8 changes (mobile usability)
--------------------------------------
- Yellow (#FFFF00) header cells: Car, Team, Class, Total, and every CP.
- On screens <=650px, only the Car column is frozen, allowing swipe access
  to the CP columns. Team, Class, and Total scroll with the CPs.
- On phones, remove the scoreboard's 70vh maximum height so all car rows
  remain reachable by scrolling down the page.
- Desktop/tablet still freeze Car, Team, Class, and Total.
- The existing score/color/Firebase logic is unchanged.

Deployment: from this extracted directory run
  firebase deploy --only hosting --project fir-tut-5e284
