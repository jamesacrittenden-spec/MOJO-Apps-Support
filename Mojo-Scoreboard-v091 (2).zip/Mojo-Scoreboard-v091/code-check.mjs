
import{initializeApp}from'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import{getAuth,signInAnonymously,onAuthStateChanged}from'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import{getDatabase,ref,onValue,set,get}from'https://www.gstatic.com/firebasejs/11.10.0/firebase-database.js';
// Firebase web application configuration, copied from Firebase Console.
// These identifiers are public web configuration, not Rallymaster credentials.
const config={
  apiKey:'AIzaSyBIqUd4F1krY_23RXsCC7Mum532QcmEVbE',
  authDomain:'fir-tut-5e284.firebaseapp.com',
  databaseURL:'https://fir-tut-5e284-default-rtdb.firebaseio.com',
  projectId:'fir-tut-5e284',
  storageBucket:'fir-tut-5e284.firebasestorage.app',
  messagingSenderId:'735206599406',
  appId:'1:735206599406:web:78581c6f246c564715e1ff',
  measurementId:'G-BZY5Y6T629'
};
const app=initializeApp(config),db=getDatabase(app),auth=getAuth(app);
const el=id=>document.getElementById(id),status=s=>el('status').textContent=s,error=s=>el('error').textContent=s;
let stopCars=null,stopMax=null,currentEvent='',carsData={},requestId=0,maxScore=null,maxWatchingFor=-1;
const CLASS_COLORS=['#b9e6fa','#c2f5aa','#ffdda8','#e2d3ff','#ffcbd8','#c7eee7','#f4e6a5','#d6e4fc','#e6d4ba','#b5ead7','#f3d1f3','#d8edb8'];
function renderMaxStatus(){const override=Number(el('maxOverride').value);const manual=el('maxOverride').value!==''&&Number.isFinite(override)&&override>0;el('maxFallback').classList.toggle('hide',maxScore!==null);el('maxStatus').textContent=maxScore!==null?`Maximum timing score: ${maxScore} (from Rallymaster Event Settings)`:manual?`Maximum timing score: ${override} (manual display setting; no Firebase changes)`:'Maximum timing score: inaccessible under current Firebase rules. Enter it below to enable red highlighting.'}
function watchMaxScore(event,id){if(stopMax){stopMax();stopMax=null}maxScore=null;renderMaxStatus();if(!event)return;
  stopMax=onValue(ref(db,`${event}/Settings/MaxScore`),snap=>{if(id!==requestId)return;const v=snap.val();const n=Number(v);maxScore=(v!==null&&v!==''&&Number.isFinite(n)&&n>0)?n:null;renderMaxStatus();build()},()=>{if(id!==requestId)return;maxScore=null;renderMaxStatus();build()});}

function typeOfCP(v){const t=String(v?.type??v?.Type??'').trim().toLowerCase();if(t.startsWith('checkpoint')||t.startsWith('checkpt'))return'';if(t.startsWith('restart:')||t==='restart')return'R';if(t==='timechk'||t==='time check'||t.startsWith('time check:'))return'TC';if(t==='offcourse'||t==='off course control'||t.startsWith('off course'))return'OFF';return''}
function scoreValue(v){const x=v?.score??v?.Score;return x===undefined||x===null?'0':String(x)}
// The database records penalty magnitude as positive; timing error carries early/late direction.
// Use the sign for display ONLY. Never change the official total or the penalty magnitude.
function displayCheckpointScore(v, cpType, tenths){
  const magnitude=Number(scoreValue(v));
  if(!Number.isFinite(magnitude))return scoreValue(v);
  const error=String(v?.error??v?.Error??'').trim();
  const timing=cpType!== 'OFF'&&cpType!== 'R'&&cpType!== 'TC';
  const early=timing&&magnitude!==0&&(/\bearly\b/i.test(error)||/^\s*-/.test(error));
  return (early?'-':'')+Math.abs(magnitude).toFixed(tenths?1:0);
}
function build(){const cars=Object.entries(carsData||{}).filter(([k,v])=>v&&typeof v==='object').map(([id,v])=>({id,...v}));const cps=new Map();for(const car of cars)for(const [id,record]of Object.entries(car.CPs||{})){if(!record||typeof record!=='object')continue;const num=Number(id);if(!Number.isFinite(num))continue;const old=cps.get(id);const t=typeOfCP(record);if(!old||(!old.type&&t))cps.set(id,{id,num,type:t});}const cpList=[...cps.values()].sort((a,b)=>a.num-b.num);
// A rally using tenths may contain integer-valued scores as well. Infer
// precision from any observed fractional score or preserved decimal string.
const hasDecimal=x=>x!==undefined&&x!==null&&x!==''&&(String(x).includes('.')||(Number.isFinite(Number(x))&&!Number.isInteger(Number(x))));
const tenths=cars.some(c=>hasDecimal(c.score)||Object.values(c.CPs||{}).some(cp=>cp&&hasDecimal(cp.score??cp.Score)));
const formatScore=x=>{const n=Number(x);return Number.isFinite(n)?n.toFixed(tenths?1:0):String(x??'0')};
const score=v=>{const n=Number(v?.score??0);return Number.isFinite(n)?n:0};const cls=v=>String(v?.ClassRunning||'');const carNumber=v=>{const n=Number(v.id);return Number.isFinite(n)?n:Number.MAX_SAFE_INTEGER};let sort=el('sort').value;cars.sort((a,b)=>sort==='car'?(carNumber(a)-carNumber(b)):sort==='class'?(cls(a).localeCompare(cls(b))||score(a)-score(b)||carNumber(a)-carNumber(b)):(score(a)-score(b)||carNumber(a)-carNumber(b)));
const classes=[...new Set(cars.map(c=>cls(c)).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
const classColors=new Map(classes.map((name,i)=>[name,CLASS_COLORS[i%CLASS_COLORS.length]]));
const legend=document.createDocumentFragment();for(const name of classes){const span=document.createElement('span');const swatch=document.createElement('i');swatch.className='class-swatch';swatch.style.background=classColors.get(name);span.append(swatch,document.createTextNode(name));legend.append(span)}el('classKey').replaceChildren(legend);
const h=document.createElement('tr');for(const label of ['Car','Team','Class','Total',...cpList.map(c=>c.id+(c.type?' '+c.type:''))]){const th=document.createElement('th');th.textContent=label;if(/^\d/.test(label)){const id=label.split(' ')[0];const types=[...new Set(cars.map(c=>c.CPs?.[id]?.type??c.CPs?.[id]?.Type).filter(x=>x!==undefined&&x!==null))];th.title='Firebase CP type(s): '+(types.join(' | ')||'Unknown')}h.append(th)}el('table').tHead.replaceChildren(h);const body=document.createDocumentFragment();for(const car of cars){const row=document.createElement('tr');function td(text,classname='',bg){const cell=document.createElement('td');cell.textContent=text;cell.className=classname;if(bg){cell.style.setProperty('--class-color',bg)}row.append(cell)}
const carClass=cls(car),classColor=classColors.get(carClass);
td(car.id,classColor?'class-color':'',classColor);
td([car.Driver,car.Navigator].filter(Boolean).join(' / '),classColor?'class-color':'',classColor);
td(carClass,classColor?'class-color':'',classColor);
td(formatScore(car.score??0),classColor?'class-color':'',classColor);
for(const cp of cpList){const v=car.CPs?.[cp.id];if(!v){td('x','score-missing');continue}const t=cp.type||typeOfCP(v);if(t==='R'||t==='TC'){td('✓','pass');continue}
const s=scoreValue(v),n=Number(s),manual=Number(el('maxOverride').value),effectiveMax=maxScore??(el('maxOverride').value!==''&&Number.isFinite(manual)&&manual>0?manual:null);let color='';
if(t==='OFF'){if(Number.isFinite(n)&&n===0)color='score-zero';else if(Number.isFinite(n)&&n>0)color='penalty'}
else if(Number.isFinite(n)){if(effectiveMax!==null&&Math.abs(n-effectiveMax)<0.000001)color='score-max';else if(n===0)color='score-zero';else if(n>=0.1-1e-9&&n<=0.9+1e-9)color='score-near-zero'}
td(displayCheckpointScore(v,t,tenths),color);
}body.append(row)}el('table').tBodies[0].replaceChildren(body);status(`${cars.length} cars · ${cpList.length} reported checkpoints · Live`)}
function watchCars(event){++requestId;if(stopCars){stopCars();stopCars=null}carsData={};maxWatchingFor=-1;el('maxOverride').value='';watchMaxScore('',requestId);build();if(!event){status('Choose a rally.');return}const id=requestId;status('Connecting to '+event+'…');stopCars=onValue(ref(db,event+'/Cars'),snap=>{if(id!==requestId)return;el('passwordPanel').classList.add('hide');error('');carsData=snap.val()||{};if(maxWatchingFor!==id){maxWatchingFor=id;watchMaxScore(event,id)}build()},err=>{if(id!==requestId)return;if(String(err.code||'').toLowerCase().includes('permission_denied')){status('Scoreboard password required.');el('passwordPanel').classList.remove('hide')}else{status('Unable to load scoreboard.');error(err.message)}})}
el('sort').addEventListener('change',build);el('maxOverride').addEventListener('input',()=>{renderMaxStatus();build()});
el('event').addEventListener('change',()=>{currentEvent=el('event').value;el('password').value='';el('passwordPanel').classList.add('hide');error('');watchCars(currentEvent)});
el('password').addEventListener('keydown',e=>{if(e.key==='Enter')el('unlock').click()});
el('unlock').addEventListener('click',async()=>{if(!currentEvent)return;el('unlock').disabled=true;error('');try{if(!auth.currentUser)await signInAnonymously(auth);await set(ref(db,`members/${currentEvent}/${auth.currentUser.uid}`),{role:'viewer',password:el('password').value});watchCars(currentEvent)}catch(e){error(String(e.code||'').toLowerCase().includes('permission_denied')?'Incorrect scoreboard password or access denied.':e.message)}finally{el('unlock').disabled=false}});
try{await signInAnonymously(auth);const snap=await get(ref(db,'eventList'));const items=Object.keys(snap.val()||{}).sort((a,b)=>a.localeCompare(b));el('event').replaceChildren(new Option('-- Select rally --',''),...items.map(x=>new Option(x,x)));status(items.length?'Choose a rally.':'No rallies found.')}catch(e){status('Unable to connect.');error('Check Firebase anonymous sign-in and web app configuration: '+e.message)}
